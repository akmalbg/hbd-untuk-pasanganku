HBD Trend versi video reference
1. Buka index.html di browser.
2. Untuk GitHub Pages, upload seluruh isi folder ini ke repository.
3. File index.html harus berada di root repository.
4. Musik akan mulai setelah tombol Play ditekan karena aturan autoplay browser.
Kode diary: love / sayang / 2026
